#DOST - 为Git与Office文档打造的可视化工具
#DOST - A Visualized Utility for Git and Office Documents
---
<br/>
##屏幕截图 Screenshots
###a)初始界面 Initial Page
![scrsht1](https://raw.githubusercontent.com/TankleL/dost/master/.img/screen-shot-001.png)
###b)工作界面 Working Page
![scrsht2](https://raw.githubusercontent.com/TankleL/dost/master/.img/screen-shot-002.png)
###c)等待界面 Waiting Status
![scrsht3](https://raw.githubusercontent.com/TankleL/dost/master/.img/screen-shot-003.png)
###d)Office Word文档浏览界面 Browsing a *Microsoft Office Word* document
![scrsht4](https://raw.githubusercontent.com/TankleL/dost/master/.img/screen-shot-004.png)